package com.example.scrolmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void call1st(View v){
        Intent i = new Intent(this , sec.class);
        startActivityForResult(i,1);
    }


    // To open intent with data and read the result
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data){
        // To check if the operation is successful and the it's my result
        if(resultCode == RESULT_OK && requestCode == 1){
            // To extract data from intent
            String order = "Order is: "+ data.getStringExtra("coffee_Type") +
                    data.getStringExtra("addTo_Coffee");
            // Display result as toast message
            Toast.makeText(getApplicationContext(), order, Toast.LENGTH_LONG).show();
        }
    }
}
