package com.example.scrolmenu;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;

public class sec extends AppCompatActivity {


    private String coffeeType;
    private String addTocoffee;

    private Button mkOrder;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sec);

    mkOrder = (Button) findViewById(R.id.button2);
    }

    public void selectCoffee(View v){
        switch (v.getId()){
        case R.id.crmlMachiatoBtn:
            coffeeType = "crmlMachiato";
            break;
        case R.id.mochaBtn:
            coffeeType = "mocha";
            break;
            case R.id.latteBtn:
                coffeeType = "latte";
                break;
            case R.id.esprsoBtn:
                coffeeType = "espresso";
                break;
            case R.id.CappuccinoBtn:
                coffeeType = "Cappuccino";
                break;
            case R.id.amrcanoBtn:
                coffeeType = "amrcano";

    } }
}

